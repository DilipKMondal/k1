variable "org" {
  description = "Short organisation prefix. Control plane name is built as <org>-<env>-cp."
  type        = string
  default     = "sedgwick"

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{1,7}$", var.org))
    error_message = "org must be 2-8 lowercase alphanumeric characters starting with a letter."
  }
}

variable "env" {
  description = "Environment name. Second element of the control plane name. Select the matching Terraform workspace before applying - see README.md."
  type        = string

  validation {
    condition     = contains(["sandbox", "dev", "qa", "uat", "production"], var.env)
    error_message = "env must be one of sandbox, dev, qa, uat, production."
  }
}

variable "cp_description" {
  description = "Konnect control plane description."
  type        = string
  default     = "Managed by Terraform"
}

variable "konnect_server_url" {
  description = "Konnect API endpoint. Change only for a non-global (EU/AU) geo."
  type        = string
  default     = "https://global.api.konghq.com"
}

variable "konnect_entity_region" {
  description = "Konnect data-residency region this environment's control plane lives in (us, eu, au). Must match the org's actual region - the system account's role grant is region-scoped and a mismatch fails at apply, not silently."
  type        = string
  default     = "us"
}

variable "terraform_token_expires_at" {
  description = "Expiry (RFC3339) for this environment's terraform system-account access token. No default - pick a rotation date deliberately per environment rather than inheriting a stale default."
  type        = string
}

variable "ca_cert_path" {
  description = "Path, relative to this repo's root, to the CA certificate PEM that Sedgwick PKI provides. Shared across every environment by default (certs/ca-chain.pem) - override per environment in that environment's .tfvars only if Sedgwick ever issues a separate CA per environment. This is a plain path string, not the cert content, so it's fine as a variable default (file()/path.module can't appear in a variable default, only in a local)."
  type        = string
  default     = "certs/ca-chain.pem"
}

variable "kong_image_repo" {
  description = "Docker repository for the Kong Gateway image."
  type        = string
  default     = "kong/kong-gateway"
}

variable "kong_image_tag" {
  description = "Kong Gateway image tag."
  type        = string
  default     = "3.15.0.5-rhel"
}

variable "kong_client_max_body_size" {
  description = "Value for KONG_NGINX_HTTP_CLIENT_MAX_BODY_SIZE. '0' is Kong's default (no limit)."
  type        = string
  default     = "0"
}

variable "kong_client_body_buffer_size" {
  description = "Value for KONG_NGINX_HTTP_CLIENT_BODY_BUFFER_SIZE. Kong's default is 8k."
  type        = string
  default     = "8k"
}

variable "kong_proxy_port" {
  type    = number
  default = 8000
}

variable "kong_proxy_ssl_port" {
  type    = number
  default = 8443
}

variable "kong_status_port" {
  type    = number
  default = 8100
}

variable "kong_linux_user" {
  description = "Existing Linux user on the RHEL9 host that runs Kong. Terraform does not create it - see scripts/configure-host.sh."
  type        = string
  default     = "kong-dp"
}

variable "kong_linux_group" {
  type    = string
  default = "kong-dp"
}

variable "kong_linux_uid" {
  description = "UID for the Linux kong-dp user. Must equal the kong UID inside the Kong container - verify with `docker run --rm --user 0 --entrypoint sh <image> -c 'id kong'`."
  type        = number
  default     = 1000
}

variable "kong_linux_gid" {
  type    = number
  default = 1000
}

variable "dp_config_dir" {
  type    = string
  default = "/opt/kong"
}

variable "dp_certs_dir" {
  description = "Directory on each RHEL9 host where the data-plane leaf certificate lands. Not written by Terraform, and never staged in this repo - see the security note in README.md."
  type        = string
  default     = "/opt/kong/certs"
}

variable "dp_logs_dir" {
  type    = string
  default = "/opt/kong/logs"
}

###############################################################################
# Documentation only - Terraform does not act on this. A running record of
# which RHEL9 hosts belong to this environment, so `terraform output
# dp_hosts` gives one place to check "what's in qa right now" as VMs are
# added over time. Update the environment's .tfvars and re-apply (a state-
# only change, no resources are touched) whenever a new VM joins.
###############################################################################

variable "dp_hosts" {
  description = "RHEL9 data-plane hostnames/IPs in this environment, for reference only."
  type = list(object({
    hostname = string
    ip       = optional(string, "")
  }))
  default = []
}
