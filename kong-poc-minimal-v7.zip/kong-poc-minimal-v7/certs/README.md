# certs

Exactly one file is meant to live here permanently: `ca-chain.pem`, the CA
certificate that signs every data-plane leaf certificate, in every
environment. Overwrite the placeholder with the real one from Sedgwick PKI,
once - it's shared across `sandbox`/`dev`/`qa`/`uat`/`production` because
Sedgwick issues one org CA, not a separate one per environment. If that
ever changes, override `ca_cert_path` in the specific environment's
`.tfvars` rather than adding more files here.

Sedgwick PKI delivers a PFX per environment (e.g.
`dev.us.op.api.sedgwick.net_SEDCA.pfx`), not a plain PEM. Extract it once:

```sh
PFX="dev.us.op.api.sedgwick.net_SEDCA.pfx"
PASS='the-password-they-gave-you'

openssl pkcs12 -in "$PFX" -clcerts -nokeys -out cluster.crt -passin pass:"$PASS"
openssl pkcs12 -in "$PFX" -nocerts -nodes -out cluster.key -passin pass:"$PASS"
openssl pkcs12 -in "$PFX" -cacerts -nokeys -chain -out ca-chain.pem -passin pass:"$PASS"
```

If OpenSSL rejects the password even though it's correct, the PFX is
probably using legacy RC2/3DES encryption - add `-legacy` to each command.

## What ends up in this folder, and for how long

| File | Stays here permanently? |
| ---- | ------------------------ |
| `ca-chain.pem` | **Yes** - this is the one file this folder exists for |
| `<env>...pfx` (the original) | **No** - delete once extraction is done |
| `cluster.crt` | **No** - copy to `/opt/kong/certs/` on the target VM, then delete here |
| `cluster.key` | **No** - copy to `/opt/kong/certs/` on the target VM, then delete here |

It's normal for the PFX, `cluster.crt`, and `cluster.key` to sit in this
folder briefly mid-extraction. `.gitignore` blocks all three from ever being
committed (by extension, and by exact filename as a second layer), but
gitignore only helps if nobody runs `git add -f` or `git add -A` without
checking `git status` first. Delete them from this folder as soon as
they're copied onto the VM they belong to - don't let this folder become a
long-term parking spot for live key material just because git won't commit
it.

```sh
git status   # confirm cluster.crt / cluster.key / *.pfx show as untracked
             # or don't show at all - never as "changes to be committed"
```

## Why the CA cert lives here but leaf certs never do

This repo's earlier single-VM version also committed the data-plane leaf
certificate and key to git, for convenience on a one-off local test. That
doesn't hold up once this repo is the thing reused for every environment,
including production, potentially with several VMs per environment:

- The CA certificate is one file, changes rarely, and is meaningless without
  a leaf certificate to present alongside it - on its own it's a public key,
  not a credential that can authenticate anything.
- A leaf certificate's **private key** is a live credential for one specific
  VM. Multiply that by every VM across five environments and this repo
  would accumulate a growing pile of active secrets in git history that
  never really goes away, even after a file is deleted or rotated.

So: the CA/chain cert is git-tracked here, once. Every leaf certificate,
key, and the source PFX are staged directly onto their VM and then deleted
from this folder - never written into this repo - see the per-VM staging
steps in the top-level README and in `scripts/README.md`.

## Sanity check before every apply

```sh
openssl verify -CAfile ca-chain.pem cluster.crt
# expect: cluster.crt: OK
```
Run this once per new leaf certificate you receive, before copying it onto
its VM - a leaf signed by a different CA than the one in this file will
apply cleanly in Terraform and only fail later, as a data plane that never
reaches `Connected`.
