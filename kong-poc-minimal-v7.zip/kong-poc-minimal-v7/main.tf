###############################################################################
# One control plane per environment, same flat repo reused every time a new
# environment's VMs come online. Select the environment with a Terraform
# workspace (isolates state per environment, no directory copy-pasting) and
# pass its .tfvars file:
#
#   terraform workspace new qa      # first time only
#   terraform workspace select qa
#   terraform apply -var-file=environments/qa.tfvars
#
# One system account per environment authenticates Terraform for that
# environment specifically - see the section below. Still no teams, no
# control-plane groups - this stays the minimal shape otherwise. See
# kong-poc-rhel9-v3 if/when org-wide RBAC (teams) is needed.
###############################################################################

resource "konnect_gateway_control_plane" "this" {
  name         = "${var.org}-${var.env}-cp"
  description  = var.cp_description
  cluster_type = "CLUSTER_TYPE_CONTROL_PLANE"
  auth_type    = "pki_client_certs"

  labels = {
    managed_by = "terraform"
    env        = var.env
  }
}

###############################################################################
# CP/DP mTLS - enterprise CA. One CA certificate, shared across every
# environment because Sedgwick PKI signs all data-plane leaf certificates
# from the same org CA - see certs/README.md. If that ever changes (a
# separate CA per environment), override ca_cert_path in that environment's
# .tfvars; nothing else here needs to change.
#
# The data-plane LEAF certificate/key are never staged in this repo, in any
# environment, including production - see the security note in README.md
# for why that line is drawn differently than the CA certificate.
#
# A variable default cannot call file() or reference path.module (Terraform
# rejects that at parse time), so this has to be a local rather than living
# on a variable's default.
###############################################################################

locals {
  custom_ca_cert = sensitive(file("${path.module}/${var.ca_cert_path}"))
}

resource "konnect_gateway_ca_certificate" "this" {
  control_plane_id = konnect_gateway_control_plane.this.id
  cert             = local.custom_ca_cert
}
# NOTE: verify konnect_gateway_ca_certificate's exact argument names against
# the konnect provider version pinned in versions.tf before first apply.

###############################################################################
# Rendered bootstrap file - one per environment, named by env so switching
# workspaces never overwrites another environment's rendered file. Written
# locally only; Terraform does not reach any RHEL9 host - see scripts/README.md
# for the manual staging steps, once per new VM.
###############################################################################

locals {
  dp_bootstrap_env = templatefile("${path.module}/dp-bootstrap.env.tftpl", {
    org                     = var.org
    env                     = var.env
    cp_id                   = konnect_gateway_control_plane.this.id
    cp_name                 = konnect_gateway_control_plane.this.name
    cp_endpoint_host        = replace(konnect_gateway_control_plane.this.config.control_plane_endpoint, "https://", "")
    telemetry_endpoint_host = replace(konnect_gateway_control_plane.this.config.telemetry_endpoint, "https://", "")
    image                   = "${var.kong_image_repo}:${var.kong_image_tag}"
    config_dir              = var.dp_config_dir
    certs_dir               = var.dp_certs_dir
    logs_dir                = var.dp_logs_dir
    kong_user               = var.kong_linux_user
    kong_group              = var.kong_linux_group
    proxy_port              = var.kong_proxy_port
    proxy_ssl_port          = var.kong_proxy_ssl_port
    status_port             = var.kong_status_port
    client_max_body_size    = var.kong_client_max_body_size
    client_body_buffer_size = var.kong_client_body_buffer_size
  })
}

resource "local_file" "dp_bootstrap_env" {
  filename        = "${path.module}/rendered/${var.env}.dp-bootstrap.env"
  content         = local.dp_bootstrap_env
  file_permission = "0640"
}

###############################################################################
# System account for running Terraform against THIS environment. Scoped to
# this environment's own control plane only - a token for sedgwick-qa-cp
# grants nothing against sedgwick-production-cp or any other environment.
# That's a deliberate difference from kong-poc-rhel9-v3's single org-wide
# terraform-bootstrap account: with no teams in this repo, a direct
# konnect_system_account_role grant per environment is both simpler and
# tighter-scoped than routing through a shared team would be.
#
# Bootstrapping order, per environment (same chicken-and-egg shape as v3,
# just scoped down to one environment instead of the whole org): the very
# first apply in a new workspace has to authenticate as something else
# (KONNECT_TOKEN, a personal token, or an org-admin credential) because this
# account doesn't exist yet. That first apply creates the account, its role,
# and its token in the same run. Every apply after that can use
# KONNECT_SPAT set to this environment's own token instead.
###############################################################################

resource "konnect_system_account" "terraform" {
  name        = "${var.org}-${var.env}-terraform"
  description = "Runs Terraform against ${konnect_gateway_control_plane.this.name} only."
}

resource "konnect_system_account_role" "terraform" {
  account_id       = konnect_system_account.terraform.id
  entity_id        = konnect_gateway_control_plane.this.id
  entity_region    = var.konnect_entity_region
  entity_type_name = "Control Planes"
  role_name        = "Admin"
}

resource "konnect_system_account_access_token" "terraform" {
  account_id = konnect_system_account.terraform.id
  name       = "${var.org}-${var.env}-terraform-token"
  expires_at = var.terraform_token_expires_at
}
# NOTE: same caveat as the CA-certificate resource above - verify the exact
# output attribute name (access_token vs token) against the pinned provider
# version before first apply. The token is only ever readable at creation;
# see the note on the access_token output in outputs.tf.
