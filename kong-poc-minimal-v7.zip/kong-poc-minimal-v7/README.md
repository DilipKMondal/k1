# kong-poc-minimal (v7)

Same flat structure as the earlier single-VM version - one `main.tf`, no
`platform/envs/` directories, no modules - now reused across five
environments: `sandbox`, `dev`, `qa`, `uat`, `production`. This is the repo
to run every time a new environment's VMs come online, not a one-off.

Each environment gets exactly **one Konnect control plane** and any number
of RHEL9 data-plane VMs - Kong hybrid mode is built for many data planes per
control plane, so three VMs in `qa` is the same control plane, run three
times, not three control planes.

## What changed from the single-VM version

| # | Change |
| - | ------ |
| 1 | Five environments (`sandbox`/`dev`/`qa`/`uat`/`production`), same flat `main.tf`, selected via **Terraform workspaces** rather than five copy-pasted directories. |
| 2 | `provision-host.sh` renamed to **`configure-host.sh`** - the old name implied it provisions the VM, but VM provisioning happens elsewhere, before this script ever runs. This only configures an already-provisioned host. |
| 3 | Only the **CA/chain certificate** is committed to the repo now (`certs/ca-chain.pem`, shared across all five environments). **Leaf certificates and the source PFX are never committed**, in any environment, including production - see the security note below for why that line moved. |
| 4 | `dp_hosts` per environment is a running, informational list - update it as VMs are added so `terraform output dp_hosts` stays a source of truth. |
| 5 | Each environment now has its own dedicated system account for running Terraform, scoped to that environment's control plane only - see "Naming convention: system accounts" below. |
| 6 | `dev.tfvars` now carries the real values confirmed on `d-dfweq-vua-023`: `kong_linux_uid = 1015`, `kong_linux_gid = 10710` (not the `1000`/`1000` variable defaults), and its `dp_hosts` entry. Certs are delivered as PFX, not plain PEM - `certs/README.md` covers the `openssl pkcs12` extraction, and `.gitignore` explicitly blocks `*.pfx` in addition to the existing `*.crt`/`*.key` rules. |

## Why leaf certs moved out of the repo

The single-VM version committed the leaf cert and key too, as a convenience
for one local smoke test. That doesn't scale to five environments with
potentially several VMs each: every leaf key is a live credential for one
specific VM, and a repo that accumulates one per VM across `sandbox`
through `production` accumulates a growing pile of active secrets in git
history that outlives any single rotation. The CA certificate is different
- one file, changes rarely, and is meaningless on its own without a leaf
cert to present alongside it. So: CA cert committed once, leaf certs staged
by hand onto each VM and never written into this repo. Full reasoning in
[`certs/README.md`](certs/README.md).

## First-time setup (once per machine you run Terraform from)

```bash
git clone <repo-url> kong-poc-minimal-v4
cd kong-poc-minimal-v4
terraform init
export KONNECT_TOKEN="kpat_your_token_here"
```

Drop the real Sedgwick PKI CA certificate into `certs/ca-chain.pem`,
overwriting the placeholder - see [`certs/README.md`](certs/README.md).

## Runbook: a new environment's VMs just came online

This is the part you'll repeat every time.

### 1. Create the control plane, once per environment

First apply in a new workspace authenticates with a personal token, since
this environment's own system account doesn't exist yet:

```bash
terraform workspace new qa        # only if this workspace doesn't exist yet
terraform workspace select qa
export KONNECT_TOKEN="kpat_your_token_here"
terraform plan  -var-file=environments/qa.tfvars
terraform apply -var-file=environments/qa.tfvars
```

This creates `sedgwick-qa-cp`, uploads the CA, **and** creates a system
account scoped to this environment only - see "Naming convention: system
accounts" below. Grab its token immediately, since Konnect never exposes it
again after this apply:

```bash
terraform output -raw terraform_access_token
```

Store that in your secret manager, then use it for every subsequent apply
against `qa` specifically:

```bash
export KONNECT_SPAT="<the token from the previous step>"
unset KONNECT_TOKEN
```

Confirm: **Gateway Manager → sedgwick-qa-cp → Certificates** shows the CA.

```bash
terraform output -raw rendered_file   # e.g. ./rendered/qa.dp-bootstrap.env
```

## Naming convention: system accounts

Each environment gets its own Terraform-running system account, scoped to
that environment's control plane only - a token for `qa` grants nothing
against `production` or any other environment. Deliberately different from
`kong-poc-rhel9-v3`'s single org-wide `terraform-bootstrap` account: with no
teams in this repo, a direct role grant per environment (`konnect_system_account_role`,
no team involved) is both simpler and tighter-scoped than routing through a
shared team would be.

| Object | Pattern | Example (`qa`) |
| ------ | ------- | --------------- |
| System account | `<org>-<env>-terraform` | `sedgwick-qa-terraform` |
| Access token | `<org>-<env>-terraform-token` | `sedgwick-qa-terraform-token` |

Rotation: there's no in-place rotate. Set a real date in
`terraform_token_expires_at` in that environment's `.tfvars` (each currently
has a placeholder), and when it's time to rotate, `terraform taint
konnect_system_account_access_token.terraform && terraform apply` - grab the
new token immediately the same way as above.

### 2. Stage and start each VM in that environment

Repeat this whole block once per VM - `configure-host.sh` and
`bootstrap.sh` don't know or care how many other VMs exist in `qa`.

```bash
scp rendered/qa.dp-bootstrap.env \
  scripts/configure-host.sh scripts/bootstrap.sh scripts/docker-compose.yml \
  youruser@<vm-ip>:/tmp/

ssh youruser@<vm-ip>
sudo mkdir -p /opt/kong/certs
sudo mv /tmp/{configure-host.sh,bootstrap.sh,docker-compose.yml} /opt/kong/
sudo mv /tmp/qa.dp-bootstrap.env /opt/kong/dp-bootstrap.env
```

Get this VM's leaf certificate from Sedgwick PKI directly - **not** via
this repo - and place it, then verify the chain before starting anything:

```bash
sudo mv cluster.crt cluster.key /opt/kong/certs/   # wherever PKI delivered them
openssl verify -CAfile <path-to-ca-chain.pem> /opt/kong/certs/cluster.crt
# expect: cluster.crt: OK
```

```bash
cd /opt/kong
sudo chmod +x configure-host.sh bootstrap.sh
sudo ./configure-host.sh
sudo ./bootstrap.sh /opt/kong/dp-bootstrap.env
```

### 3. Verify

```bash
curl -s http://127.0.0.1:8100/status
docker ps --format '{{.Names}} {{.Status}}'   # expect: kong-dp Up (healthy)
```

**Gateway Manager → sedgwick-qa-cp → Data Plane Nodes** - each VM should
appear as its own `Connected` node on the same control plane.

### 4. Record the host, optional but recommended

Add the VM to `dp_hosts` in `environments/qa.tfvars`, then:

```bash
terraform apply -var-file=environments/qa.tfvars
```

This is a state-only change - no Konnect object is touched - it just keeps
`terraform output dp_hosts` current as a running inventory.

## Switching environments

```bash
terraform workspace list
terraform workspace select dev
terraform apply -var-file=environments/dev.tfvars
```

Each workspace has its own isolated state under `terraform.tfstate.d/<env>/`
- applying in `dev` never touches `qa`'s control plane or state.

## Production

There is nothing production-specific in this repo's Terraform - same
`main.tf`, same resources, `environments/production.tfvars` is the same
shape as every other environment's file. The difference is procedural, not
technical: get a second pair of eyes on `terraform plan` output before
`apply` in the `production` workspace, and confirm which credential
(`KONNECT_TOKEN`/`KONNECT_SPAT`) is set in your shell and which Konnect org
it authenticates against before running anything - see
`environments/production.tfvars` for the same note in-line.

## Tear down an environment

```bash
terraform workspace select qa
terraform destroy -var-file=environments/qa.tfvars
```

Removes that environment's control plane and CA upload only. Doesn't touch
any VM - stop each VM's container and remove `/opt/kong` by hand if the
hosts themselves are being decommissioned too.

## Known limits (intentional, staying minimal)

- One control plane per environment, not `internal`/`external`/`global`
  groups. No control plane groups either.
- No teams, no control-plane groups. Each environment's system account is
  Admin on its own control plane only - broader than per-service RBAC, but
  scoped per environment rather than org-wide.
- Local Terraform state (`terraform.tfstate.d/`), no shared backend yet -
  see the commented-out `backend` block in `versions.tf`.
- `dp_hosts` is a manually-maintained list, not auto-discovered.

## If this needs to grow further

`kong-poc-rhel9-v3` has the same core resources wrapped in modules, with
`internal`/`global` control-plane groups per environment and org-wide RBAC
(teams, roles, a bootstrap system account). Move to that shape if/when this
repo's limits above actually start to hurt - not before.
