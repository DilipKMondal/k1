# certs

Exactly one file lives here: `sedgwick-ca.pem`, the CA certificate that
signs every data-plane leaf certificate, in every environment. Overwrite the
placeholder with the real one from Sedgwick PKI, once - it's shared across
`sandbox`/`dev`/`qa`/`uat`/`production` because Sedgwick issues one org CA,
not a separate one per environment. If that ever changes, override
`ca_cert_path` in the specific environment's `.tfvars` rather than adding
more files here.

## Why the CA cert lives here but leaf certs never do

This repo's earlier single-VM version also committed the data-plane leaf
certificate and key to git, for convenience on a one-off local test. That
doesn't hold up once this repo is the thing reused for every environment,
including production, potentially with several VMs per environment:

- The CA certificate is one file, changes rarely, and is meaningless without
  a leaf certificate to present alongside it - on its own it's a public key,
  not a credential that can authenticate anything.
- A leaf certificate's **private key** is a live credential for one specific
  VM. Multiply that by every VM across five environments and this repo
  would accumulate a growing pile of active secrets in git history that
  never really goes away, even after a file is deleted or rotated.

So: the CA cert is git-tracked here, once. Every leaf certificate and key
is staged directly onto its VM by hand or via whatever secure channel
Sedgwick PKI uses, and never written into this repo - see the per-VM
staging steps in the top-level README and in `scripts/README.md`.

## Sanity check before every apply

```sh
openssl verify -CAfile sedgwick-ca.pem /path/to/that-vms/cluster.crt
# expect: cluster.crt: OK
```
Run this once per new leaf certificate you receive, against whichever VM
you're about to stage it on - a leaf signed by a different CA than the one
in this file will apply cleanly in Terraform and only fail later, as a data
plane that never reaches `Connected`.
