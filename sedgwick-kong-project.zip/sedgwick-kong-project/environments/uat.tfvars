###############################################################################
# uat environment
# terraform workspace new uat      (first time only)
# terraform workspace select uat
# terraform apply -var-file=environments/uat.tfvars
###############################################################################

org = "sedgwick"
env = "uat"

cp_description = "Kong hybrid-mode control plane - uat"

kong_image_repo = "kong/kong-gateway"
kong_image_tag  = "3.15.0.5-rhel"

kong_linux_user  = "kong-dp"
kong_linux_group = "kong-dp"

dp_config_dir = "/opt/kong"
dp_certs_dir  = "/opt/kong/certs"
dp_logs_dir   = "/opt/kong/logs"

kong_client_max_body_size    = "0"
kong_client_body_buffer_size = "8k"

# Update this list as VMs are added to uat - informational only, Terraform
# does not act on it. Re-apply after editing; it's a state-only change.
dp_hosts = []
