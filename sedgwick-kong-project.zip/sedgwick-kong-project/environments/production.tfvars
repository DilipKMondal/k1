###############################################################################
# production environment
# terraform workspace new production      (first time only)
# terraform workspace select production
# terraform apply -var-file=environments/production.tfvars
#
# Same shape as every other environment - there is nothing production-
# specific in this repo's Terraform. The difference is procedural: get a
# second pair of eyes on `terraform plan` output before `apply` here, and
# double, triple check that KONNECT_SPAT/KONNECT_TOKEN in this shell is
# actually authenticated against the intended Konnect org before running
# anything.
###############################################################################

org = "sedgwick"
env = "production"

cp_description = "Kong hybrid-mode control plane - production"

kong_image_repo = "kong/kong-gateway"
kong_image_tag  = "3.15.0.5-rhel"

kong_linux_user  = "kong-dp"
kong_linux_group = "kong-dp"

dp_config_dir = "/opt/kong"
dp_certs_dir  = "/opt/kong/certs"
dp_logs_dir   = "/opt/kong/logs"

kong_client_max_body_size    = "0"
kong_client_body_buffer_size = "8k"

# Update this list as VMs are added to production - informational only,
# Terraform does not act on it. Re-apply after editing; it's a state-only
# change.
dp_hosts = []
