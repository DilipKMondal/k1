output "control_plane_id" {
  value = konnect_gateway_control_plane.this.id
}

output "control_plane_name" {
  value = konnect_gateway_control_plane.this.name
}

output "control_plane_endpoint" {
  value = konnect_gateway_control_plane.this.config.control_plane_endpoint
}

output "telemetry_endpoint" {
  value = konnect_gateway_control_plane.this.config.telemetry_endpoint
}

output "ca_certificate_id" {
  value = konnect_gateway_ca_certificate.this.id
}

output "rendered_file" {
  description = "Local path to copy onto each RHEL9 host in this environment as /opt/kong/dp-bootstrap.env."
  value       = local_file.dp_bootstrap_env.filename
}

output "dp_hosts" {
  description = "Documented host inventory for this environment - informational only."
  value       = var.dp_hosts
}
