terraform {
  required_version = "~> 1.11"

  required_providers {
    konnect = {
      source  = "kong/konnect"
      version = "3.22.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.5"
    }
  }

  # Local state, one file per workspace under terraform.tfstate.d/<env>/ -
  # fine while this is one person's test rig. Before this carries real qa/
  # uat/production traffic, point at a shared backend so state isn't only
  # on one laptop:
  # backend "azurerm" {
  #   resource_group_name  = "sedgwick-tfstate-rg"
  #   storage_account_name = "sedgwicktfstate"
  #   container_name       = "kong-konnect"
  #   key                  = "kong-poc-minimal-v4/terraform.tfstate"
  # }
}
