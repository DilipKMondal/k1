# Credentials come from the environment only - KONNECT_TOKEN (personal
# access token) or KONNECT_SPAT (system account token). Never set
# personal_access_token or system_account_access_token here.
provider "konnect" {
  server_url = var.konnect_server_url
}
