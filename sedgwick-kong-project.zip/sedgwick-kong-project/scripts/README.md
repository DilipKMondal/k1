# scripts

The data-plane install path, run once per VM. Kong is installed and
configured here, **not** by Terraform - Terraform stops at emitting Konnect
config and one `dp-bootstrap.env` per environment.

- `configure-host.sh` - one-time RHEL9 host configuration: creates the
  `kong-dp` user/group at the fixed UID/GID, installs Docker if missing,
  fixes ownership on `/opt/kong`, `/opt/kong/certs`, `/opt/kong/logs`.
  Named "configure", not "provision" - the VM itself is already
  provisioned by the time this runs; this only sets it up to run Kong.
  Fetches nothing over the network - every artifact it touches must
  already be staged on the host.
- `bootstrap.sh` - sources `dp-bootstrap.env` and starts the Kong container.
- `docker-compose.yml` - runs the Kong Gateway container.

## Contract, per VM

| File | Placed by | Contents |
| ---- | --------- | -------- |
| `/opt/kong/configure-host.sh` | you, from this repo | this repo's `configure-host.sh` |
| `/opt/kong/bootstrap.sh` | you, from this repo | this repo's `bootstrap.sh` |
| `/opt/kong/docker-compose.yml` | you, from this repo | this repo's `docker-compose.yml` |
| `/opt/kong/dp-bootstrap.env` | you, from `rendered/<env>.dp-bootstrap.env` | `terraform apply` output for that environment |
| `/opt/kong/certs/cluster.crt` | Sedgwick PKI, direct to this VM | this VM's leaf certificate - never staged in this repo |
| `/opt/kong/certs/cluster.key` | Sedgwick PKI, direct to this VM | this VM's leaf private key - never staged in this repo |

```sh
sudo ./configure-host.sh
# stage dp-bootstrap.env and cluster.crt/cluster.key, then:
sudo ./configure-host.sh   # re-run to fix ownership on what just landed
sudo /opt/kong/bootstrap.sh /opt/kong/dp-bootstrap.env
```

Every VM in an environment runs through this same sequence - three VMs in
`qa` means running this five-step block three times, once per VM, each with
its own leaf certificate from PKI. `configure-host.sh` and `bootstrap.sh`
don't know or care how many other VMs exist in the environment.
