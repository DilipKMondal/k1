#!/usr/bin/env bash
# One-time RHEL9 host CONFIGURATION for a Kong data plane - creates the
# kong-dp user, installs Docker, fixes directory ownership. This is
# deliberately not called "provision" - VM provisioning (the VM existing at
# all) happens elsewhere, before this script ever runs; this only configures
# an already-provisioned host. Run manually (or via whatever CM tool
# Sedgwick Unix admin uses) with Unix admin-access already granted for this
# host. Fetches nothing over the network - every artifact below is expected
# to already be staged on the host.
#
# Expects, before running:
#   /opt/kong/bootstrap.sh          (this repo's scripts/bootstrap.sh)
#   /opt/kong/docker-compose.yml    (this repo's scripts/docker-compose.yml)
#   /opt/kong/dp-bootstrap.env      (Terraform output rendered/<group>.dp-bootstrap.env)
#   /opt/kong/certs/cluster.crt     (delivered by Sedgwick PKI)
#   /opt/kong/certs/cluster.key     (delivered by Sedgwick PKI)
#
# Idempotent and guarded throughout: safe to re-run after any of the above
# files are updated.
set -euo pipefail

KONG_USER="${KONG_LINUX_USER:-kong-dp}"
KONG_GROUP="${KONG_LINUX_GROUP:-kong-dp}"
KONG_UID="${KONG_LINUX_UID:-1000}"
KONG_GID="${KONG_LINUX_GID:-1000}"
CONFIG_DIR="${KONG_CONFIG_DIR:-/opt/kong}"
CERTS_DIR="${KONG_CERTS_DIR:-/opt/kong/certs}"
LOGS_DIR="${KONG_LOGS_DIR:-/opt/kong/logs}"

log() { echo "[configure-host] $*"; }

###############################################################################
# kong-dp user and group
###############################################################################

getent group "$KONG_GROUP" >/dev/null || groupadd --gid "$KONG_GID" "$KONG_GROUP"
getent passwd "$KONG_USER" >/dev/null || useradd --uid "$KONG_UID" --gid "$KONG_GID" \
  --shell /sbin/nologin --home-dir /var/lib/kong-dp --create-home "$KONG_USER"

# The container reads cluster.crt/cluster.key through a bind mount as its own
# kong user. If the host UID differs, Kong fails with a bare "Permission
# denied" on cluster.crt and nothing else - assert it here so the identity is
# blamed, not the certificate. Reached only when the user pre-existed at
# different ids.
if [[ "$(id -u "$KONG_USER")" != "$KONG_UID" || "$(id -g "$KONG_USER")" != "$KONG_GID" ]]; then
  log "FATAL: $KONG_USER is $(id -u "$KONG_USER"):$(id -g "$KONG_USER") on this host," \
      "expected $KONG_UID:$KONG_GID to match the Kong container - see the" \
      "kong_linux_uid note in platform/envs/<env>/variables.tf"
  exit 1
fi

###############################################################################
# Docker and the compose plugin
###############################################################################

if ! command -v docker >/dev/null; then
  dnf -y install dnf-plugins-core
  dnf config-manager --add-repo https://download.docker.com/linux/rhel/docker-ce.repo
  dnf -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin
  systemctl enable --now docker
  usermod -aG docker "$KONG_USER"
fi

###############################################################################
# Directory ownership and permissions
#
# Terraform does not write cluster.crt/cluster.key - Sedgwick PKI delivers
# them directly onto the host into CERTS_DIR. This script only fixes
# ownership/permissions on whatever is already there; it never fetches or
# generates certificate material.
###############################################################################

install -d -m 0755 "$CONFIG_DIR"
install -d -m 0750 -o "$KONG_USER" -g "$KONG_GROUP" "$CERTS_DIR"
install -d -m 0750 -o "$KONG_USER" -g "$KONG_GROUP" "$LOGS_DIR"

chmod 0755 "$CONFIG_DIR/bootstrap.sh" 2>/dev/null || log "WARN: $CONFIG_DIR/bootstrap.sh not staged yet"
chmod 0644 "$CONFIG_DIR/docker-compose.yml" 2>/dev/null || log "WARN: $CONFIG_DIR/docker-compose.yml not staged yet"

if [[ -f "$CONFIG_DIR/dp-bootstrap.env" ]]; then
  chown "$KONG_USER:$KONG_GROUP" "$CONFIG_DIR/dp-bootstrap.env"
  chmod 0640 "$CONFIG_DIR/dp-bootstrap.env"
else
  log "WARN: $CONFIG_DIR/dp-bootstrap.env not staged yet - copy the Terraform-rendered file for this group before running bootstrap.sh"
fi

for f in cluster.crt cluster.key; do
  if [[ -f "$CERTS_DIR/$f" ]]; then
    chown "$KONG_USER:$KONG_GROUP" "$CERTS_DIR/$f"
  else
    log "WARN: $CERTS_DIR/$f not delivered yet - bootstrap.sh will refuse to start without it"
  fi
done
chmod 0640 "$CERTS_DIR/cluster.crt" 2>/dev/null || true
chmod 0600 "$CERTS_DIR/cluster.key" 2>/dev/null || true

log "host prep complete. Run $CONFIG_DIR/bootstrap.sh $CONFIG_DIR/dp-bootstrap.env once every file above is staged."
