#!/usr/bin/env bash
# Kong data-plane bootstrap. Lives at /opt/kong/bootstrap.sh on the RHEL9
# host, placed there by ops alongside docker-compose.yml, dp-bootstrap.env,
# and the cluster.crt/cluster.key that Sedgwick PKI delivers separately.
# Invoked directly, or via configure-host.sh after host configuration.
#
# Terraform owns every value this script consumes via dp-bootstrap.env. If
# something is needed that is not in the env file, add it to
# platform/envs/<env>/dp-bootstrap.env.tftpl rather than hardcoding it here.
set -euo pipefail

ENV_FILE="${1:-/opt/kong/dp-bootstrap.env}"
COMPOSE_FILE="/opt/kong/docker-compose.yml"

log() { echo "[kong-bootstrap] $*"; }

[[ -r "$ENV_FILE" ]] || { log "FATAL: $ENV_FILE not readable"; exit 1; }
[[ -r "$COMPOSE_FILE" ]] || { log "FATAL: $COMPOSE_FILE missing"; exit 1; }

# Values are quoted in the env file precisely so this is safe.
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

for v in KONG_IMAGE KONG_CLUSTER_CONTROL_PLANE KONG_CLUSTER_CERT KONG_CLUSTER_CERT_KEY; do
  [[ -n "${!v:-}" ]] || { log "FATAL: $v is empty in $ENV_FILE"; exit 1; }
done

for f in "$KONG_CLUSTER_CERT" "$KONG_CLUSTER_CERT_KEY"; do
  [[ -s "$f" ]] || { log "FATAL: $f missing or empty - has Sedgwick PKI delivered the DP certificate to this host yet?"; exit 1; }
done

install -d -m 0750 -o "${KONG_RUN_USER:-kong-dp}" -g "${KONG_RUN_GROUP:-kong-dp}" "${KONG_LOGS_DIR:-/opt/kong/logs}"

log "control plane        : $KONNECT_CP_NAME ($KONNECT_CP_ID)"
log "cluster endpoint      : $KONG_CLUSTER_CONTROL_PLANE"
log "image                 : $KONG_IMAGE"

log "starting data plane"
docker compose -f "$COMPOSE_FILE" up -d --remove-orphans

# Kong needs to complete the mTLS handshake with the control plane before the
# status port answers.
log "waiting for status endpoint"
for _ in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:${KONG_STATUS_LISTEN##*:}/status" >/dev/null 2>&1; then
    log "data plane is up"
    exit 0
  fi
  sleep 5
done

log "FATAL: status endpoint did not come up within 150s"
docker compose -f "$COMPOSE_FILE" logs --tail=50
exit 1
